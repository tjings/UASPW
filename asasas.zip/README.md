# UAS Pemweb
Bioskop

## Catatan
Setiap kali ada update database, jangan lupa untuk import ulang.

## Cara Install
* `git clone repo_url`, lalu copy ke folder `htdocs` dalam XAMPP.
* Pastikan nama foldernya UASPW, jadi `htdocs/UASPW`. Ekstrak foldernya dan pastikan yang ada cuma isi project CI nya aja yang ada di dalam folder (application, assets, system, dll).
* Import database yang terletak di `assets/uas.sql`. Udah dibikinin query auto drop database + auto create database setiap kali import, jadi langsung import aja.
* Login dengan username: `admin` dan password `admin`.
* Bila ingin login dengan fasilitas user: `user` dan password `user`.
* Selesai. Selamat mencoba.