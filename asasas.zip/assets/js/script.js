$(document).ready(function() {
  $('#movie').DataTable();
});